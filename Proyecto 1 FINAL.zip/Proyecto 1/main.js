let doctores = [];
let pacientes = [];

function agregarDatosDoctor(nombredoctor, apellidodoctor, ceduladoctor, listdoctor, consultoriodoctor, correodoctor) {
    var Nuevodoctor = {
        nombre: nombredoctor,
        apellido: apellidodoctor,
        cc:ceduladoctor,
        listadeespecialidad: listdoctor,
        consultorio: consultoriodoctor,
        correo: correodoctor
    };
    doctores.push(Nuevodoctor);
}

function agregarDatosPaciente(nombrepaciente, cedulapaciente, apellidopaciente, edadpaciente,correopaciente,telefonopaciente, listpaciente) {
    var Nuevopaciente = {
        nombre: nombrepaciente,
        cc: cedulapaciente,
        apellido: apellidopaciente,
        edad: edadpaciente,
        correo: correopaciente,
        telefono: telefonopaciente,
        listadeespecialidad: listpaciente,
        
        
    };
    pacientes.push(Nuevopaciente);
}

document.querySelector('#Registrar').addEventListener('click', guardarDatosDoctorTabla);
document.querySelector('#formPaciente').addEventListener('submit', guardarDatosPacienteTabla);

function guardarDatosDoctorTabla() {
    var guardarnombredoctor = document.querySelector('#nomd').value,
        guardarapellidodoctor = document.querySelector('#apelld').value,
        guardarceduladoctor = document.querySelector('#cedoc').value,
        guardarconsultoriodoctor = document.querySelector('#consuldoc').value,
        guardarcorreodoctor = document.querySelector('#corredoc').value,
        listadoctor = document.querySelector('#especialidadDoctor').value;

    agregarDatosDoctor(guardarnombredoctor, guardarapellidodoctor, guardarceduladoctor, listadoctor, guardarconsultoriodoctor, guardarcorreodoctor);
    imprimirTablaDoctores();
}

function guardarDatosPacienteTabla(event) {
    event.preventDefault(); 
    var guardarnombrepaciente = document.querySelector('#nomp').value,
        guardarcedulapaciente = document.querySelector('#cedp').value,
        guardarapellidopaciente = document.querySelector('#apellp').value,
        guardaredadpaciente = document.querySelector('#edadp').value,
        guardatelpaciente = document.querySelector('#telp').value,
        guardarcorreopaciente = document.querySelector('#correop').value,
        listapaciente = document.querySelector('#especialidadPaciente').value;

        agregarDatosPaciente(guardarnombrepaciente, guardarcedulapaciente, guardarapellidopaciente,guardaredadpaciente, guardatelpaciente, guardarcorreopaciente,listapaciente);
    imprimirTablaPacientes();
}

function imprimirTablaDoctores() {
    var listaDoctores = doctores,
        tbodyDoctores = document.querySelector('#tabladoctores tbody');

    tbodyDoctores.innerHTML = '';

    for (var i = 0; i < listaDoctores.length; i++) {
        var row = tbodyDoctores.insertRow(i),
            nombreCelda = row.insertCell(0),
            apellidoCelda = row.insertCell(1),
            cedulaCelda = row.insertCell(2),
            listCelda = row.insertCell(3),
            consultorioCelda = row.insertCell(4),
            correoCelda = row.insertCell(5);

        nombreCelda.innerHTML = listaDoctores[i].nombre;
        apellidoCelda.innerHTML = listaDoctores[i].apellido;
        cedulaCelda.innerHTML = listaDoctores[i].cc;
        listCelda.innerHTML = listaDoctores[i].listadeespecialidad;
        consultorioCelda.innerHTML = listaDoctores[i].consultorio;
        correoCelda.innerHTML = listaDoctores[i].correo;

        tbodyDoctores.appendChild(row);
    }
}

function imprimirTablaPacientes() {
    var listaPacientes = pacientes,
        tbodyPacientes = document.querySelector('#tablaPacientes tbody');

    tbodyPacientes.innerHTML = '';

    for (var i = 0; i < listaPacientes.length; i++) {
        var row = tbodyPacientes.insertRow(i),
            nombreCelda = row.insertCell(0),
            cedulaCelda = row.insertCell(1),
            apellidoCelda = row.insertCell(2),
            EdadCelda = row.insertCell(3),
            TelefonoCelda = row.insertCell(4),
            correoCelda = row.insertCell(5),
            listCelda = row.insertCell(6);

        nombreCelda.innerHTML = listaPacientes[i].nombre;
        cedulaCelda.innerHTML = listaPacientes[i].cc;
        apellidoCelda.innerHTML = listaPacientes[i].apellido;
        EdadCelda.innerHTML = listaPacientes[i].edad;
        TelefonoCelda.innerHTML = listaPacientes[i].telefono;
        correoCelda.innerHTML = listaPacientes[i].correo;
        listCelda.innerHTML = listaPacientes[i].listadeespecialidad;

        tbodyPacientes.appendChild(row);
    }
}
